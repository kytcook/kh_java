package com.mvc.step2;

public class ModelAndView {

}
